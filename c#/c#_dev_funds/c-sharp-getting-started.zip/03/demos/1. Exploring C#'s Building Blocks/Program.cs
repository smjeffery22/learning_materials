﻿using System;

namespace MyFirstProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        static FahrenheitToCelsius(temperatureFahrenheit)
        {
            temperatureCelsius = (temperatureFahrenheit - 32) / 1.8;
            return temperatureCelsius;
        }
    }
}
