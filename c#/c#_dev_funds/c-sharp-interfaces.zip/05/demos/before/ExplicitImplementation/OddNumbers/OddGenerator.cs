﻿using System.Collections;
using System.Collections.Generic;

namespace OddNumbers
{
    public class OddGenerator
    {
    }
}
