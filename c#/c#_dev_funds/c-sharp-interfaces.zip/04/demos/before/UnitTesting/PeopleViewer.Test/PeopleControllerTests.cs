using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PeopleViewer.Controllers;
using PersonReader.Interface;
using System.Collections.Generic;
using System.Linq;

namespace PeopleViewer.Test
{
    [TestClass]
    public class PeopleControllerTests
    {
        [TestMethod]
        public void PeopleController_OnRuntimeReaderAction_ModelIsPopulated()
        {
            Assert.Inconclusive();
        }

        [TestMethod]
        public void PeopleController_OnRuntimeReaderAction_ReaderTypeIsPopulated()
        {
            Assert.Inconclusive();
        }
    }
}
